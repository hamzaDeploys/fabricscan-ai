FabricScan AI dataset
=====================

1025 images, 256 x 256 px, 4 classes: good, hole, stain, broken_thread.
Split by source image (group-aware, seed 42) into train / val / test; no source image appears in two splits.

class              train    val   test
good                 242     52     52
hole                 120     26     26
stain                197     43     43
broken_thread        156     34     34

File names: <group>__<original name>.jpg. The group is the source image; all views of it share one split.

Sources and licences (SOURCES.csv lists every original file):
   321  Kaggle: pulakdroy/fabric-defect-without-augmentation (CC BY 4.0)
   238  Kaggle: anmol055/clothes-staindefect-detection (CC BY 4.0)
   218  Kaggle: nexuswho/fabric-defects-dataset (CC BY 4.0)
   138  Kaggle: hyungjung/stitchingnet-dataset (CC BY-NC 4.0)
   110  Kaggle: rajkumarl/people-clothing-segmentation (CC0)

The images keep the licences of their sources. CC BY 4.0: give credit to the dataset authors.
CC BY-NC 4.0 (StitchingNet): credit the authors and do not use commercially.
CC0 (People Clothing Segmentation): no conditions.
Built for the FabricScan AI university project with scripts/import_sources.py, clean_dataset.py and split_dataset.py.
